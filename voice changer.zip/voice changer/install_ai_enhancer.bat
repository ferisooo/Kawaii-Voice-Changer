@echo off
REM ============================================================
REM  Install the optional AI Enhancer (DeepFilterNet)
REM
REM  Run this ONCE if you want the "AI Enhance" toggle to work.
REM  It installs the DeepFilterNet package into the voice
REM  changer's Python environment. Everything else works without
REM  it -- this is purely optional.
REM
REM  NOTE: DeepFilterNet may fail to install on some Windows
REM  setups (it has a native component). If it errors out, the
REM  AI Enhance toggle simply stays unavailable and nothing else
REM  is affected.
REM ============================================================

setlocal
cd /d "%~dp0server"

if not exist "venv\Scripts\activate.bat" (
    echo [!] No "venv" found. Run start_voice_changer.bat first to set it up.
    pause
    goto :end
)

call "venv\Scripts\activate.bat"

echo ============================================================
echo  Installing DeepFilterNet (AI Enhancer)...
echo  This may take a few minutes.
echo ============================================================
echo.
pip install deepfilternet
if errorlevel 1 goto :failed

echo.
echo ============================================================
echo  Done! Start the voice changer and turn on "AI Enhance"
echo  in the Extra Controls panel.
echo ============================================================
pause
goto :end

:failed
echo.
echo [ERROR] DeepFilterNet failed to install on this system.
echo   This can happen on Windows due to its native component.
echo   The rest of the voice changer is unaffected; the AI Enhance
echo   toggle will just stay unavailable.
pause
goto :end

:end
endlocal
