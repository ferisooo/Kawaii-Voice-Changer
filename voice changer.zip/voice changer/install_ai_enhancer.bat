@echo off
REM ============================================================
REM  Install the optional AI Enhancer (DeepFilterNet)
REM
REM  Run this ONCE if you want the "AI Enhance" toggle to work.
REM  It installs the DeepFilterNet package into the voice
REM  changer's Python environment. Everything else works without
REM  it -- this is purely optional.
REM
REM  NOTE: DeepFilterNet may fail to install on some Windows
REM  setups (it has a native component). If it errors out, the
REM  AI Enhance toggle simply stays unavailable and nothing else
REM  is affected.
REM ============================================================

setlocal
cd /d "%~dp0server"

REM Use the project's virtual environment if it exists, otherwise fall back to
REM system Python (same logic as start_voice_changer.bat).
if exist "venv\Scripts\activate.bat" (
    call "venv\Scripts\activate.bat"
    echo Using the project's venv.
) else (
    echo No "venv" found - installing into your system Python instead.
)

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found. Install Python first, then retry.
    pause
    goto :end
)

echo ============================================================
echo  Installing DeepFilterNet (AI Enhancer)...
echo  This may take a few minutes.
echo ============================================================
echo.
python -m pip install deepfilternet
if errorlevel 1 goto :failed

echo.
echo ============================================================
echo  Done! Start the voice changer and turn on "AI Enhance"
echo  in the Extra Controls panel.
echo ============================================================
pause
goto :end

:failed
echo.
echo [ERROR] DeepFilterNet failed to install on this system.
echo   This can happen on Windows due to its native component.
echo   The rest of the voice changer is unaffected; the AI Enhance
echo   toggle will just stay unavailable.
pause
goto :end

:end
endlocal
