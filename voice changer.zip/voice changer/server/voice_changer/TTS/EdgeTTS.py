"""
Text-to-Speech front-end for the RVC voice changer.

RVC is a voice *conversion* model: it re-timbres an existing waveform into the
target voice, it cannot synthesize speech from text on its own. To get
"text-to-speech in an RVC voice" we use a two-stage pipeline:

    text --> [edge-tts] --> neutral speech audio --> [RVC convert] --> target voice

This module only covers the first stage (synthesis). The synthesized audio is
then fed into the existing RVC offline conversion path
(``VoiceChangerManager.convert_audio`` -> ``RVCr2.convert``).

edge-tts streams MP3 from Microsoft's online TTS service, so this feature
requires outbound internet access.
"""
import os
import logging
import tempfile

import numpy as np
import librosa
import edge_tts

logger = logging.getLogger(__name__)

# Decode the synthesized speech directly at the rate RVC works in internally
# (16kHz HuBERT rate). Passing 16kHz audio to RVCr2.convert keeps the
# downstream feature-size math exact and avoids an extra resample.
TTS_SAMPLE_RATE = 16000

DEFAULT_VOICE = "en-US-AriaNeural"

# edge-tts voice list is static; cache it after the first successful fetch.
_voices_cache: list[dict] | None = None


async def list_voices() -> list[dict]:
    """Return the available edge-tts voices (cached after first call)."""
    global _voices_cache
    if _voices_cache is None:
        voices = await edge_tts.list_voices()
        _voices_cache = [
            {
                "name": v["ShortName"],
                "gender": v.get("Gender", ""),
                "locale": v.get("Locale", ""),
                "friendlyName": v.get("FriendlyName", ""),
            }
            for v in sorted(voices, key=lambda x: x.get("ShortName", ""))
        ]
    return _voices_cache


async def synthesize(
    text: str,
    voice: str = DEFAULT_VOICE,
    rate: str = "+0%",
    pitch: str = "+0Hz",
) -> tuple[np.ndarray, int]:
    """Synthesize ``text`` with edge-tts and return ``(audio_float32, sample_rate)``.

    ``rate`` (e.g. "+0%", "-10%") and ``pitch`` (e.g. "+0Hz", "-20Hz") are
    passed through to edge-tts to tweak the source speech before conversion.
    """
    if not text or not text.strip():
        raise ValueError("Text must not be empty.")

    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)

    # edge-tts yields MP3; write to a temp file then decode with librosa, the
    # same audio backend the rest of the server already relies on.
    tmp_path: str | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
            tmp_path = f.name
        await communicate.save(tmp_path)
        audio, _ = librosa.load(tmp_path, sr=TTS_SAMPLE_RATE, mono=True)
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as e:
                logger.warning(f"Failed to remove temp TTS file {tmp_path}: {e}")

    return audio.astype(np.float32), TTS_SAMPLE_RATE
