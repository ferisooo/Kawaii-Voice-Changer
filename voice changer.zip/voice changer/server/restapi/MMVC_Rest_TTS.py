import io
import logging

import numpy as np
from scipy.io.wavfile import write as wav_write

from fastapi import APIRouter, Request
from fastapi.responses import Response, JSONResponse

from voice_changer.VoiceChangerManager import VoiceChangerManager
from voice_changer.TTS.EdgeTTS import synthesize, list_voices, is_available, DEFAULT_VOICE
from Exceptions import VoiceChangerIsNotSelectedException

logger = logging.getLogger(__name__)


class MMVC_Rest_TTS:
    """Text-to-Speech endpoints.

    Text is synthesized with edge-tts, then (optionally) re-voiced through the
    currently selected RVC model. Requires outbound internet for synthesis.
    """

    def __init__(self, voiceChangerManager: VoiceChangerManager):
        self.voiceChangerManager = voiceChangerManager
        self.router = APIRouter()
        self.router.add_api_route("/tts_voices", self.tts_voices, methods=["GET"])
        self.router.add_api_route("/tts", self.tts, methods=["POST"])

    async def tts_voices(self):
        if not is_available():
            return JSONResponse(
                status_code=503,
                content={"error": "edge-tts is not installed. Run 'pip install edge-tts' and restart the server."},
            )
        try:
            voices = await list_voices()
            return JSONResponse(content={"voices": voices})
        except Exception as e:
            logger.exception(e)
            return JSONResponse(
                status_code=502,
                content={"error": "Failed to fetch TTS voices. Internet access is required for edge-tts."},
            )

    async def tts(self, req: Request):
        if not is_available():
            return JSONResponse(
                status_code=503,
                content={"error": "edge-tts is not installed. Run 'pip install edge-tts' and restart the server."},
            )
        try:
            body = await req.json()
        except Exception:
            return JSONResponse(status_code=400, content={"error": "Invalid JSON body."})

        text = (body.get("text") or "").strip()
        voice = body.get("voice") or DEFAULT_VOICE
        rate = body.get("rate", "+0%")
        pitch = body.get("pitch", "+0Hz")
        # When false, return the raw synthesized speech without RVC conversion
        # (useful for comparison / debugging).
        do_convert = body.get("convert", True)

        if not text:
            return JSONResponse(status_code=400, content={"error": "Text must not be empty."})

        try:
            audio, sr = await synthesize(text, voice, rate, pitch)
        except Exception as e:
            logger.exception(e)
            return JSONResponse(
                status_code=502,
                content={"error": "TTS synthesis failed. Internet access is required for edge-tts."},
            )

        try:
            if do_convert:
                out_audio, out_sr = self.voiceChangerManager.convert_audio(audio, sr)
            else:
                out_audio, out_sr = audio, sr
        except VoiceChangerIsNotSelectedException:
            return JSONResponse(
                status_code=409,
                content={"error": "No voice changer model is selected. Select an RVC model slot first."},
            )
        except Exception as e:
            logger.exception(e)
            return JSONResponse(status_code=500, content={"error": "Voice conversion failed. Check server logs."})

        # Encode as 16-bit PCM WAV.
        pcm = (np.clip(out_audio, -1.0, 1.0) * 32767).astype(np.int16)
        buf = io.BytesIO()
        wav_write(buf, int(out_sr), pcm)

        return Response(
            content=buf.getvalue(),
            headers={"Content-Type": "audio/wav", "Cache-Control": "no-store"},
        )

