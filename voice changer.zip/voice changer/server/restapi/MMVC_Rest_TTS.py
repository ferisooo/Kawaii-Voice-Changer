import io
import logging

import numpy as np
from scipy.io.wavfile import write as wav_write

from fastapi import APIRouter, Request
from fastapi.responses import Response, JSONResponse, HTMLResponse

from voice_changer.VoiceChangerManager import VoiceChangerManager
from voice_changer.TTS.EdgeTTS import synthesize, list_voices, DEFAULT_VOICE
from Exceptions import VoiceChangerIsNotSelectedException

logger = logging.getLogger(__name__)


class MMVC_Rest_TTS:
    """Text-to-Speech endpoints.

    Text is synthesized with edge-tts, then (optionally) re-voiced through the
    currently selected RVC model. Requires outbound internet for synthesis.
    """

    def __init__(self, voiceChangerManager: VoiceChangerManager):
        self.voiceChangerManager = voiceChangerManager
        self.router = APIRouter()
        self.router.add_api_route("/tts_voices", self.tts_voices, methods=["GET"])
        self.router.add_api_route("/tts", self.tts, methods=["POST"])
        self.router.add_api_route("/tts_ui", self.tts_ui, methods=["GET"])

    async def tts_voices(self):
        try:
            voices = await list_voices()
            return JSONResponse(content={"voices": voices})
        except Exception as e:
            logger.exception(e)
            return JSONResponse(
                status_code=502,
                content={"error": "Failed to fetch TTS voices. Internet access is required for edge-tts."},
            )

    async def tts(self, req: Request):
        try:
            body = await req.json()
        except Exception:
            return JSONResponse(status_code=400, content={"error": "Invalid JSON body."})

        text = (body.get("text") or "").strip()
        voice = body.get("voice") or DEFAULT_VOICE
        rate = body.get("rate", "+0%")
        pitch = body.get("pitch", "+0Hz")
        # When false, return the raw synthesized speech without RVC conversion
        # (useful for comparison / debugging).
        do_convert = body.get("convert", True)

        if not text:
            return JSONResponse(status_code=400, content={"error": "Text must not be empty."})

        try:
            audio, sr = await synthesize(text, voice, rate, pitch)
        except Exception as e:
            logger.exception(e)
            return JSONResponse(
                status_code=502,
                content={"error": "TTS synthesis failed. Internet access is required for edge-tts."},
            )

        try:
            if do_convert:
                out_audio, out_sr = self.voiceChangerManager.convert_audio(audio, sr)
            else:
                out_audio, out_sr = audio, sr
        except VoiceChangerIsNotSelectedException:
            return JSONResponse(
                status_code=409,
                content={"error": "No voice changer model is selected. Select an RVC model slot first."},
            )
        except Exception as e:
            logger.exception(e)
            return JSONResponse(status_code=500, content={"error": "Voice conversion failed. Check server logs."})

        # Encode as 16-bit PCM WAV.
        pcm = (np.clip(out_audio, -1.0, 1.0) * 32767).astype(np.int16)
        buf = io.BytesIO()
        wav_write(buf, int(out_sr), pcm)

        return Response(
            content=buf.getvalue(),
            headers={"Content-Type": "audio/wav", "Cache-Control": "no-store"},
        )

    async def tts_ui(self):
        return HTMLResponse(content=_TTS_UI_HTML)


_TTS_UI_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>RVC Text-to-Speech</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 760px; margin: 2rem auto; padding: 0 1rem; color: #1a1a1a; }
  h1 { font-size: 1.4rem; }
  textarea { width: 100%; min-height: 96px; font-size: 1rem; padding: .5rem; box-sizing: border-box; }
  label { display: block; margin-top: .8rem; font-weight: 600; font-size: .9rem; }
  select, input { font-size: 1rem; padding: .35rem; margin-top: .25rem; }
  .row { display: flex; gap: 1rem; flex-wrap: wrap; }
  .row > div { flex: 1; min-width: 140px; }
  .buttons { margin-top: 1rem; display: flex; gap: .75rem; flex-wrap: wrap; }
  button { font-size: 1rem; padding: .55rem 1rem; cursor: pointer; border-radius: 6px; border: 1px solid #888; background: #f4f4f4; }
  button.primary { background: #2563eb; color: #fff; border-color: #2563eb; }
  button:disabled { opacity: .5; cursor: default; }
  #status { margin-top: 1rem; min-height: 1.2em; color: #555; }
  audio { width: 100%; margin-top: 1rem; }
  .hint { color: #666; font-size: .85rem; }
</style>
</head>
<body>
  <h1>RVC Text-to-Speech</h1>
  <p class="hint">Type text, pick a base voice, and synthesize. The audio is converted through the currently selected RVC model slot. Requires internet access (edge-tts).</p>

  <label for="text">Text</label>
  <textarea id="text" placeholder="Type something to speak...">Hello! This is text to speech, converted with my RVC voice.</textarea>

  <div class="row">
    <div>
      <label for="voice">Base voice</label>
      <select id="voice"><option>Loading voices...</option></select>
    </div>
    <div>
      <label for="rate">Rate</label>
      <input id="rate" value="+0%" />
    </div>
    <div>
      <label for="pitch">Pitch</label>
      <input id="pitch" value="+0Hz" />
    </div>
  </div>

  <div class="buttons">
    <button id="speak" class="primary">Speak (RVC voice)</button>
    <button id="speakRaw">Speak (raw TTS)</button>
  </div>

  <div id="status"></div>
  <audio id="player" controls></audio>

<script>
const $ = (id) => document.getElementById(id);
const status = $('status');

async function loadVoices() {
  try {
    const res = await fetch('tts_voices');
    const data = await res.json();
    const sel = $('voice');
    if (!data.voices || !data.voices.length) {
      sel.innerHTML = '<option>(failed to load voices)</option>';
      return;
    }
    sel.innerHTML = '';
    for (const v of data.voices) {
      const opt = document.createElement('option');
      opt.value = v.name;
      opt.textContent = `${v.name} (${v.gender})`;
      if (v.name === 'en-US-AriaNeural') opt.selected = true;
      sel.appendChild(opt);
    }
  } catch (e) {
    $('voice').innerHTML = '<option>(failed to load voices)</option>';
  }
}

async function speak(convert) {
  const text = $('text').value.trim();
  if (!text) { status.textContent = 'Please enter some text.'; return; }
  $('speak').disabled = true; $('speakRaw').disabled = true;
  status.textContent = convert ? 'Synthesizing and converting...' : 'Synthesizing...';
  try {
    const res = await fetch('tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        voice: $('voice').value,
        rate: $('rate').value || '+0%',
        pitch: $('pitch').value || '+0Hz',
        convert,
      }),
    });
    if (!res.ok) {
      let msg = 'Request failed (' + res.status + ')';
      try { const j = await res.json(); if (j.error) msg = j.error; } catch (e) {}
      status.textContent = msg;
      return;
    }
    const blob = await res.blob();
    $('player').src = URL.createObjectURL(blob);
    $('player').play();
    status.textContent = 'Done.';
  } catch (e) {
    status.textContent = 'Error: ' + e;
  } finally {
    $('speak').disabled = false; $('speakRaw').disabled = false;
  }
}

$('speak').addEventListener('click', () => speak(true));
$('speakRaw').addEventListener('click', () => speak(false));
loadVoices();
</script>
</body>
</html>
"""
